
//ADD YOUR FIREBASE LINKS HERE
const firebaseConfig = {
      apiKey: "AIzaSyD8UiHw2jzT08OB1uY6klSjcrlWomhuYIs",
      authDomain: "kwitter-89463.firebaseapp.com",
      databaseURL: "https://kwitter-89463-default-rtdb.firebaseio.com",
      projectId: "kwitter-89463",
      storageBucket: "kwitter-89463.appspot.com",
      messagingSenderId: "413310766226",
      appId: "1:413310766226:web:a0fac7bccab70914132a4b"
    };
    firebase.initializeApp(firebaseConfig);

    get_username = localStorage.getItem("user name");
    document.getElementById("welcome").innerHTML= "Welcome " + get_username + "!";

function adding_room(){
      roomname = document.getElementById("room").value;
      firebase.database().ref("/").child(roomname).update({
          purpose:"adding room name"
      });
      localStorage.setItem("room name",roomname);
      window.location="kwitter_page.html";
      }

function getData() {firebase.database().ref("/").on('value', function(snapshot) {document.getElementById("display").innerHTML = "";snapshot.forEach(function(childSnapshot) {childKey  = childSnapshot.key;
       Room_names = childKey;
      //Start code
      console.log("Room Name :" + Room_names);
      row = "<div class='room' id="+Room_names+" onclick='redirectToRoomName(this.id)'>#" +Room_names +"</div> <hr>";
      document.getElementById("display").innerHTML += row;
      //End code
      });});}
getData();

function redirectToRoomName(roomname){
      console.log("Room Name :" + roomname); 
      localStorage.setItem("room name",roomname);
      window.location="kwitter_page.html"; 
}

function logout(){
localStorage.removeItem("user name");
localStorage.removeItem("room name");
window.location= "index.html";
}